Tested with standard Python interpreter (Cpython), version 3.9.6.

To start, open a console, change directory to the same directory as main.py and enter:
python -m main
You will be greeted with a choice between five questionnaires, each specific to an optimization goal (the names should be self-explanatory):
'infrastructure_RAM',
'infrastructure_CPU',
'HA',
'latency_throughput',
'data'

In order to skip the questionnaire choice, you may also directly start a specific one via:
python -m <name>
<name> is one of the questionnaire names listed above. Once started, closely follow the instructions on the screen.

Note that this implementation does not check for input consistency. If, for example, you are asked to enter a float 0 <= x <= 1 and you enter 2, the program behavior is undefined. The program also does not check if fractions sum up to one (only relevant for 'infrastructure_*' questionnaires for the fraction a certain functionality contributes to the whole program's resource usage).