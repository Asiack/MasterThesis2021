from __future__ import annotations

import abc
from typing import Union, Any, Mapping, Dict, final, Type, cast, Callable, Tuple, Optional, Generic, TypeVar

T_co = TypeVar("T_co", covariant=True)


class SolutionStep(Generic[T_co]):
    __param_kvs: Dict[str, Any]
    # Key name -> (parameter name, parameter class, optional default value)
    __param_key_names_types_defaults: Dict[str, Tuple[str, Type[Any], Optional[Any]]]
    __descr_printed: bool
    __suppress_descr: bool
    __tab_level: int

    def __init__(self,
                 tab_level: int,
                 suppress_descr: bool,
                 **kwargs: Any):
        kwargs_: Dict[str, Any] = dict(kwargs)
        param_key_names_types_defaults_: Dict[str, Tuple[str, Type[Any], Optional[Any]]] = \
            dict(self._get_param_key_names_types_defaults())

        for k in kwargs_:
            if k in param_key_names_types_defaults_:
                if not isinstance(kwargs_[k], param_key_names_types_defaults_[k][1]):
                    try:
                        kwargs_[k] = param_key_names_types_defaults_[k][1](kwargs_[k])
                    except (Exception,) as e:
                        raise ValueError("Type mismatch in provided kwargs.") from e

        assert all(isinstance(kwargs_[k], param_key_names_types_defaults_[k][1])
                   for k in kwargs_
                   if k in param_key_names_types_defaults_)

        if not all((param_key_names_types_defaults_[k][2] is None
                    or isinstance(param_key_names_types_defaults_[k][2], param_key_names_types_defaults_[k][1]))
                   for k in param_key_names_types_defaults_):
            raise ValueError(f"Default value type mismatch.")

        self.__param_kvs = kwargs_
        self.__param_key_names_types_defaults = param_key_names_types_defaults_
        self.__descr_printed = False
        self.__tab_level = tab_level
        self.__suppress_descr = suppress_descr

    @abc.abstractmethod
    def get_name(self) -> str:
        ...

    def solve(self) -> T_co:
        assert not self.__descr_printed
        result: T_co = self.__solve_recursive(last_solution=self)
        self.__descr_printed = False
        return result

    def __solve_recursive(self,
                          last_solution: Union[T_co, SolutionStep]) -> T_co:
        if not isinstance(last_solution, SolutionStep):
            return cast(T_co, last_solution)
        else:
            return self.__solve_recursive(last_solution=last_solution._get_next_step())

    @abc.abstractmethod
    def _get_param_key_names_types_defaults(self) -> Mapping[str, Tuple[str, Type[Any], Optional[Any]]]:
        ...

    @abc.abstractmethod
    def _get_next_step(self) -> Union[T_co, SolutionStep]:
        """
        Call `self._get_param(...)` to retrieve parameters required in this SolutionStep.
        Use `self._create_solution_step(...)` as a factory method for creating new SolutionStep instances.
        """
        ...

    @final
    def _create_solution_step(self,
                              sol_step_factory: Union[Type[SolutionStep], Callable[..., SolutionStep]],
                              param_kvs_factory: Callable[[Mapping[str, Any]],
                                                          Mapping[str, Any]] = lambda mapping: mapping) -> SolutionStep:
        return sol_step_factory(**dict(param_kvs_factory(dict(self.__param_kvs))))

    @abc.abstractmethod
    def get_description(self) -> str:
        ...

    @final
    def _get_tab_level(self) -> int:
        return self.__tab_level

    @final
    def _get_param(self,
                   param_key: str) -> Any:
        assert param_key in self.__param_key_names_types_defaults

        if param_key not in self.__param_kvs:
            param_key_name: str
            expected_type: Type[Any]
            default_value: Optional[Any]
            param_key_name, expected_type, default_value = self.__param_key_names_types_defaults[param_key]

            tab_level: int = self._get_tab_level()
            if not self.__descr_printed and not self.__suppress_descr:
                print(self.get_description())
                self.__descr_printed = True

            print(((tab_level + 1) * "\t") +
                  f"Step '{self.get_name()}' requires information: " +
                  f"'{param_key_name}'" +
                  (": "
                   if default_value is None
                   else f" (press Enter for default: '{default_value}'):"))
            input_: str = input()
            if input_ == "" and default_value is not None:
                return default_value
            else:
                self.__param_kvs[param_key] = expected_type(input_)

        return self.__param_kvs[param_key]


class _RelativeResourceIncrease(SolutionStep[float]):

    __func_no: int
    __resource_name: str

    def __init__(self,
                 func_no: int,
                 resource_name: str,
                 tab_level: int,
                 suppress_descr: bool,
                 **kwargs: Any):

        self.__func_no = func_no
        self.__resource_name = resource_name

        super().__init__(tab_level=tab_level,
                         suppress_descr=suppress_descr,
                         **kwargs)

    def get_name(self) -> str:
        return f"Weighted relative {self.__resource_name}-usage increase " \
               f"contribution of functionality {self.__func_no}"

    def _get_param_key_names_types_defaults(self) -> Mapping[str, Tuple[str, Type[Any], Optional[Any]]]:
        return {
            f"rel_res_usage_{self.__func_no}": (f"Relative {self.__resource_name}-usage of functionality "
                                                f"{self.__func_no} w.r.t. the rest of the program "
                                                f"(enter a float  0 <= x <= 1, should sum up to one over all "
                                                f"functionalities)",
                                                float,
                                                None),
            f"rel_res_usage_incr_{self.__func_no}": (f"Peak relative {self.__resource_name}-usage increase of "
                                                     f"functionality {self.__func_no} (enter a float >= 0)",
                                                     float,
                                                     None),
            f"n_yrl_days_peaks_{self.__func_no}": (f"Yearly number of days with {self.__resource_name}-usage "
                                                   f"peaks of functionality {self.__func_no} "
                                                   f"(enter an integer 0 <= n <= 365)",
                                                   int,
                                                   None),
            f"avg_peak_len_{self.__func_no}": (f"Average number of seconds of {self.__resource_name}-usage "
                                               f"peaks of functionality {self.__func_no} on peak-days "
                                               f"(enter ab integer 0 <= x <= 86400 = 24 * 60 * 60)",
                                               int,
                                               None)
        }

    def _get_next_step(self) -> Union[float, SolutionStep]:
        return (self._get_param(param_key=f"rel_res_usage_{self.__func_no}")
                * self._get_param(param_key=f"rel_res_usage_incr_{self.__func_no}")
                * self._get_param(param_key=f"n_yrl_days_peaks_{self.__func_no}")
                * self._get_param(param_key=f"avg_peak_len_{self.__func_no}")
                / (365 * 24 * 60 * 60))

    def get_description(self) -> str:
        return ("\t" * self._get_tab_level()) + \
               f"{self.get_name()}.\n" + \
               ("\t" * self._get_tab_level()) + \
               f"{self.__resource_name}-usage increase w.r.t. the same period without spikes. " \
               f"Weighted with functionality's relative {self.__resource_name}-usage w.r.t. the rest of the program."


class _ResourceSolution(SolutionStep[str]):

    __resource_name: str
    __max_accepted_rel_incr_default: float

    def __init__(self,
                 resource_name: str,
                 max_accepted_rel_incr_default: float,
                 suppress_descr: bool,
                 tab_level: int,
                 **kwargs: Any):
        self.__resource_name = resource_name
        self.__max_accepted_rel_incr_default = max_accepted_rel_incr_default

        super().__init__(tab_level=tab_level,
                         suppress_descr=suppress_descr,
                         **kwargs)

    def get_name(self) -> str:
        return f"{self.__resource_name}-usage optimizer"

    def _get_param_key_names_types_defaults(self) -> Mapping[str, Tuple[str, Type[Any], Optional[Any]]]:
        return {
            "num_functs": ("Number of affected functionalities (enter an integer >= 1)",
                           int,
                           1),
            "max_rel_accepted_incr": (f"Maximal acceptable {self.__resource_name}-usage increase "
                                      f"when using modularized monolith (enter a float >= 0)",
                                      float,
                                      self.__max_accepted_rel_incr_default)
        }

    def _get_next_step(self) -> Union[str, SolutionStep]:
        max_rel_accepted_incr: float = self._get_param(param_key="max_rel_accepted_incr")
        num_functs: int = self._get_param(param_key="num_functs")
        rel_incr: float = (0.0
                           if num_functs == 0
                           else sum((_RelativeResourceIncrease(func_no=i + 1,
                                                               resource_name=self.__resource_name,
                                                               tab_level=self._get_tab_level() + 1,
                                                               suppress_descr=(i > 0)).solve()
                                     for i in range(num_functs))))
        use_ms: bool = rel_incr > max_rel_accepted_incr
        result: str = (f"Relative {self.__resource_name}-usage increase is " +
                       ("larger" if use_ms else "smaller") +
                       f" than the maximal accepted relative increase ({round(rel_incr, 6)} "
                       f"vs {round(max_rel_accepted_incr, 6)}).\n" +
                       f"Therefore go for: " +
                       ("microservices" if use_ms else "modularized monolith"))
        return result

    def get_description(self) -> str:
        return ("\t" * self._get_tab_level()) + \
               f"{self.get_name()}.\n" + \
               ("\t" * self._get_tab_level()) + \
               f"Scenario: High {self.__resource_name}-usage spikes in parts of software."


class RAMSolution(_ResourceSolution):
    def __init__(self,
                 **kwargs: Any):

        super().__init__(
            resource_name="RAM",
            max_accepted_rel_incr_default=0.4433,
            suppress_descr=False,
            tab_level=0,
            **kwargs
        )


class CPUSolution(_ResourceSolution):
    def __init__(self,
                 **kwargs: Any):

        super().__init__(
            resource_name="CPU",
            max_accepted_rel_incr_default=0.0228,
            suppress_descr=False,
            tab_level=0,
            **kwargs
        )


class HighAvailabilitySolution(SolutionStep[str]):

    def __init__(self,
                 **kwargs: Any):
        super().__init__(tab_level=0,
                         suppress_descr=False,
                         **kwargs)

    def get_name(self) -> str:
        return f"High availability optimizer"

    def _get_param_key_names_types_defaults(self) -> Mapping[str, Tuple[str, Type[Any], Optional[Any]]]:
        return {
            "all_code_ha_relevant": ("Whole code base is HA relevant "
                                     "(press Enter for 'false', anything else for 'true')",
                                     bool,
                                     None),
            "split_possible": ("Code base can be split for reduction of business process dependencies so that "
                               "isolation of HA relevant code possible while keeping "
                               "number of splits and thus required services and composite SLA minimal "
                               "(press Enter for 'false', anything else for 'true')",
                               bool,
                               None),
            "further_splits": ("After dependency removal, further reduction of split size is required aiming at "
                               "keeping small 2-pizza team busy for a year "
                               "(press Enter for 'false', anything else for 'true')",
                               bool,
                               None),
        }

    def _get_next_step(self) -> Union[str, SolutionStep]:
        all_code_ha_relevant: bool = self._get_param(param_key="all_code_ha_relevant")
        identified_ms_set: str = "You identified the minimal set of required microservices."

        if all_code_ha_relevant:
            split_possible: bool = self._get_param(param_key="split_possible")
            if split_possible:
                further_splits: bool = self._get_param(param_key="further_splits")
                if further_splits:
                    return "You chose 3x 'yes'. " \
                           "Split code base further until it fits your team size " \
                           "according to microservices principles."
                else:
                    return "You chose 2x 'yes' followed by 'no'. " + identified_ms_set
            else:
                return "You chose 'yes' and 'no'. " + identified_ms_set
        else:
            return "You chose 'no'. "\
                   "Rerun questionnaire separately for code parts which are relevant for HA " \
                   "and for those which are not."

    def get_description(self) -> str:
        return ("\t" * self._get_tab_level()) + \
               f"{self.get_name()}.\n" + \
               ("\t" * self._get_tab_level()) + \
               f"Scenario: High availability (HA) demands."


class LatencyThroughputSolution(SolutionStep[str]):

    def __init__(self,
                 **kwargs: Any):
        super().__init__(tab_level=0,
                         suppress_descr=False,
                         **kwargs)

    def get_name(self) -> str:
        return f"Latency and throughput optimizer"

    def _get_param_key_names_types_defaults(self) -> Mapping[str, Tuple[str, Type[Any], Optional[Any]]]:
        return {
            "all_code_performant": ("Whole code base is performance relevant "
                                    "(press Enter for 'false', anything else for 'true')",
                                    bool,
                                    None),
            "small_team_sufficient": ("Small 2-pizza team can develop it full time in one year "
                                      "(press Enter for 'false', anything else for 'true')",
                                      bool,
                                      None),
            "split_possible": ("Code base can be split for reduction of business process dependencies so that "
                               "isolation of performance relevant code is possible "
                               "(press Enter for 'false', anything else for 'true')",
                               bool,
                               None)
        }

    def _get_next_step(self) -> Union[str, SolutionStep]:
        all_code_performant: bool = self._get_param(param_key="all_code_performant")
        if all_code_performant:
            small_team_sufficient: bool = self._get_param(param_key="small_team_sufficient")
            if small_team_sufficient:
                return "You chose 2x 'yes'. " \
                       "Go for a monolith, but modularize it and use microservice development patterns " \
                       "so you can scale easily in the future if needed."
            else:
                return "You chose 'yes' and 'no'. " \
                       "Split code base further as per business logic until it fits the team size " \
                       "and go for event driven design minimizing the number of services in one process."
        else:
            split_possible: bool = self._get_param(param_key="split_possible")
            if split_possible:
                return "You chose 'no' and 'yes'. " \
                       "For the performance critical code: " \
                       "Develop as modularized monolith. If required, split into multiple monoliths so that " \
                       "2-pizza team can work on it full time for at least one year. " \
                       "Apply microservice development patterns so you can scale easily in the future if needed. " \
                       "Rerun questionnaire for the non-performance critical code."
            else:
                return "You chose 2x 'no'. " \
                       "Go for monolith. Consider splitting according to business logic if it is too big for the " \
                       "team size. Keep in mind that the database can be the bottleneck if shared among the services " \
                       "and some development patterns need to be applied to work around it."

    def get_description(self) -> str:
        return ("\t" * self._get_tab_level()) + \
               f"{self.get_name()}.\n" + \
               ("\t" * self._get_tab_level()) + \
               f"Scenario: High performance demands."


class DataIntegrityConsistencySolution(SolutionStep[str]):

    def __init__(self,
                 **kwargs: Any):
        super().__init__(tab_level=0,
                         suppress_descr=False,
                         **kwargs)

    def get_name(self) -> str:
        return f"Data integrity and consistency"

    def _get_param_key_names_types_defaults(self) -> Mapping[str, Tuple[str, Type[Any], Optional[Any]]]:
        return {}

    def _get_next_step(self) -> Union[str, SolutionStep]:
        return "Go for modularized monolith as long as team size permits it. Consider splitting modules " \
               "if team size grows too large. Database should be shared across modules as long as performance " \
               "permits it."

    def get_description(self) -> str:
        return ("\t" * self._get_tab_level()) + \
               f"{self.get_name()}.\n" + \
               ("\t" * self._get_tab_level()) + \
               f"Scenario: High data integrity and consistency demands " \
               f"with no acceptance for eventual integrity."
