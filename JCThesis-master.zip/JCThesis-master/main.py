from __future__ import annotations

import sys
from typing import Mapping, Final, Callable, Optional

from solution import SolutionStep, RAMSolution, CPUSolution, HighAvailabilitySolution, LatencyThroughputSolution, \
    DataIntegrityConsistencySolution


SOLUTION_NAME_MAPPING: Final[Mapping[str, Callable[..., SolutionStep]]] = {
    "infrastructure_RAM": lambda kwargs: RAMSolution(**kwargs),
    "infrastructure_CPU": lambda kwargs: CPUSolution(**kwargs),
    "HA": lambda kwargs: HighAvailabilitySolution(**kwargs),
    "latency_throughput": lambda kwargs: LatencyThroughputSolution(**kwargs),
    "data": lambda kwargs: DataIntegrityConsistencySolution(**kwargs)
}


if __name__ == '__main__':
    solution_name: Optional[str] = None
    if len(sys.argv) == 1:
        print("Choose optimization goal by typing one of the following parameters and pressing Enter: " +
              ", ".join(key for key in SOLUTION_NAME_MAPPING))
        solution_name = input()
    elif len(sys.argv) == 2:
        solution_name = sys.argv[1]

    if solution_name is None or solution_name not in SOLUTION_NAME_MAPPING:
        raise ValueError("Solution name required to be one of the following: " +
                         ", ".join(key for key in SOLUTION_NAME_MAPPING))
    else:
        print("Answer: " + SOLUTION_NAME_MAPPING[solution_name]({}).solve())
